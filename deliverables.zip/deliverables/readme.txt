##################################################################
                         Project Deliverables                    
##################################################################

📌 Jupyter Notebook  
Location: cyber-attack-predictor/notebooks/main.ipynb

💻 Web Application Code  
Location: cyber-attack-predictor/src/

📄 Report  
Location: cyber-attack-predictor/documents/Report_cyberattck_DSTI_2025.pdf

🎥 Web Application Demo  
Location: cyber-attack-predictor/media/videos/web_app_demo.mp4

🔗 GitHub Repository  
URL: https://github.com/sacumesh/cyber-attack-predictor

##################################################################
